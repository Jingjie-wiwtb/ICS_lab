#include "cachelab.h"
#include <getopt.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include<errno.h>
#include <limits.h>


static void printHelpInfo(){
	printf("Usage: ./csim [-hv] -s <num> -E <num> -b <num> -t <file>");
	printf("Options:\n");
	printf("-h get help info\n");
	printf("-v Optional verbose flag that displays trace info 可选的详细标志，可以显示trace信息\n");
	printf("-s <s> Number of set index bits 设置索引位的数量，即设定了组数\n");	
    printf("-E <E> Associativity (number of lines per set) 设置每组的行数\n");
	printf("-b <b> Number of block bits 设定了块大小\n");
	printf("-t <tracefile>: Name of the valgrind trace to replay 设定trace文件\n");
}


const char* optstring = "hvs:E:b:t:";

typedef struct{
   int valid;  //有效位标志
   long tag;   //标记位
   long time_stamp;//时间戳，记录当前行的存入时间
}Line;

typedef Line* Set;
typedef Set* Cache;
typedef struct{
    int hit;
    int miss;
    int eviction;
}Result;

//getopt() 原型： int getopt(int argc, char** argv, const char* opstring);

		
void isHit(Set lines, int E ,int tag, int vflag, Result* resultp){
        unsigned int oldest_time = UINT_MAX;  //先取最大值，一会儿找最小（最老）
        unsigned int youngest_time = 0; //先取最小值，然后找最大
        unsigned int oldest_line;
	    int hflag = 0;   //hit_flag
	  
	for(int i = 0; i < E; i++){
		if(lines[i].tag == tag && lines[i].valid == 1){  //命中
			if(vflag)
			   printf(" hit");
			hflag = 1;
			resultp->hit++;
			lines[i].time_stamp++;   //更新该行时间戳
			break;
        }

	}
	if(!hflag){   //没命中
		if(vflag)
			printf(" miss");
		
		resultp->miss++;
		
		for(int i = 0; i < E; i++){  //eviction?
			if(lines[i].time_stamp < oldest_time){ //找最早行
				oldest_time = lines[i].time_stamp;
				oldest_line = i;
			}
			if(lines[i].time_stamp > youngest_time){ //找最晚更新的时间戳以便更新
				youngest_time = lines[i].time_stamp;
			}
		}		
		lines[oldest_line].time_stamp = youngest_time + 1;//更新最晚行时间戳
		lines[oldest_line].tag = tag;   //写入新行
		
		if(lines[oldest_line].valid){   //eviction
			if(vflag)
				printf(" eviction");
			resultp->eviction++;
		}
		else{
			lines[oldest_line].valid = 1;
		}
	}		
}		


Result readAndCount(Cache cache,int s,int E,int b,FILE* traceFile,int vflag){
	
	char cmd;
	long unsigned int address;
	int tag;    //标记位
	int index;  //组索引
	
	Result result = {0,0,0};
	
	while(fscanf(traceFile, "%s %lx%*[^\n]", &cmd, &address) == 2){
		if(cmd == 'I')
			continue;
		
		tag = (address >> s) >> b;
		index = (address >> b) & ((1 << s) - 1);
		Set set = cache[index];   //找到组
		
		
		
		if(cmd == 'L' || cmd == 'S'){
			if(vflag)
		    	printf("%c %lx, ", cmd, address);
			isHit(set, E, tag, vflag, &result);
			if(vflag)
			    printf("\n");
		}
		else if(cmd == 'M'){    //读两次
			if(vflag)
		    	printf("%c %lx, ", cmd, address);
			isHit(set, E, tag, vflag, &result);
		    isHit(set, E, tag, vflag, &result);
			if(vflag)
			    printf("\n");
		}
		else
			continue;
	}
	return result;
}
						  

	
	
Cache init_Cache(int s, int E){
	int S = 1 << s;
	Cache cache;    // Cache 是 set[], Set 是 line[]
	if((cache = (Cache)malloc(sizeof(Set) * S)) == NULL){
		perror("Failed to malloc sets");
		exit(EXIT_FAILURE);
	}
	for(int i = 0; i < S; i++)
		if((cache[i] = (Set)malloc(sizeof(Line) * E)) == NULL){
			perror("Failed to malloc lines");
			exit(EXIT_FAILURE);
		}
	return cache;
}
	
//释放申请过的缓存空间
void freeMemory(Cache cache, int s, int E){
       	int S = 1 << s;
	for(int i = 0; i < S; i++)
		free(cache[i]);
	free(cache);
}

int main(int argc, char *const argv[]){	
	char opt;
	opterr = 0;    //使getopt不向stderr输出错误信息
	int vflag = 0;
	unsigned int s = 0;
	unsigned int E = 0;
	unsigned int b = 0;
	FILE* traceFile = NULL;
	
	while((opt = getopt(argc, argv, optstring)) != -1){
		
		switch(opt){
			case 'h':{
				printHelpInfo();
				//exit(0);  
				break;
			}
			case 'v':{    
				vflag = 1;   
				break;
			}
			case 's':{
			    if(atoi(optarg) <= 0){
				   printHelpInfo();
				   exit(EXIT_FAILURE);
				}
				s = atoi(optarg);   //atoi（）字符串转整数
				break;
			}
			case 'E':{
				if(atoi(optarg) <= 0){
				   printHelpInfo();
				   exit(EXIT_FAILURE);
				}  
				E = atoi(optarg);
				break;
			}
			case 'b':{
			    if(atoi(optarg) <= 0){
				   printHelpInfo();
				   exit(EXIT_FAILURE);
				}  
				b = atoi(optarg);
                break;
			}
			case 't':{
				//traceFile = fopen(optarg,"r");			
				 if ((traceFile = fopen(optarg, "r")) == NULL)
                {
					 printf("optarg:%s",optarg);
					 int errnum = errno;
                    perror("Failed to open tracefile");
					 printf("open fail errno = %d  \n", errnum);

                    exit(EXIT_FAILURE);
                }
				break;
			}
			default:
				printHelpInfo();
				continue;
		}
	}		
	
	if(s == 0 || E == 0 ||b == 0|| traceFile == NULL){  //参数设置错误,或文件不存在
	   printf("%d%d%d",s,E,b);
		printf("return!"); 
		printHelpInfo();
        exit(EXIT_FAILURE);
	}	
	
	Cache cache = init_Cache(s,E);
	
	
	Result result = readAndCount(cache, s, E, b, traceFile, vflag);
    fclose(traceFile);
	//	freeMemory(cache, s, E);
	int S = 1 << s;
	for(int i = 0; i < S; i++)
		free(cache[i]);
	free(cache);

	printSummary(result.hit, result.miss, result.eviction);
    return 0;
}
